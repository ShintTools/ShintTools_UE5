// Copyright ShintTools. All Rights Reserved.

using UnrealBuildTool;

public class ShintTools : ModuleRules
{
	public ShintTools(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicIncludePaths.AddRange(new string[]
		{
			// No additional public include paths required
		});

		PrivateIncludePaths.AddRange(new string[]
		{
			"ShintTools/Core",
			"ShintTools/UI",
			"ShintTools/Utils",
		});

		PublicDependencyModuleNames.AddRange(new string[]
		{
			"Core",
		});

		PrivateDependencyModuleNames.AddRange(new string[]
		{
			// UE Core
			"CoreUObject",
			"Engine",
			"Slate",
			"SlateCore",

			// Editor modules
			"EditorStyle",
			"EditorWidgets",
			"UnrealEd",
			"LevelEditor",
			"ToolMenus",
			"WorkspaceMenuStructure",

			// HTTP & JSON
			"HTTP",
			"Json",
			"JsonUtilities",

			// Input/Output utilities
			"InputCore",
		});

		// Ensure HTTP module is available
		if (Target.bBuildEditor)
		{
			PrivateDependencyModuleNames.AddRange(new string[]
			{
				"MainFrame",
			});
		}

		DynamicallyLoadedModuleNames.AddRange(new string[]
		{
			// No dynamically loaded modules
		});
	}
}
